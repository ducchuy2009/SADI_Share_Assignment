/*  RMIT University Vietnam
Course: COSC2440 Software Architecture: Design and Implements
Semester: 2021A
Assessment: Assignment 1
Author: Bui Duc Huy
ID: s3817842
Created date: 13/04/2021
*/


package com.company;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {

        // Declare Variable
        Scanner inp = new Scanner(System.in);
        Student s;
        Course c;
        String sID, cID, sem, opt, opt1, opt2;
        Pattern regex = Pattern.compile("\\d{4}[A-C]$");
        EnrolmentManager enrolment = new EnrolmentManager();

        // Ask users to provide enrolment file
        System.out.println("Enter the file name:");
        String fileName = inp.nextLine();
        enrolment.importFile(fileName);

        do {

            // Main menu
            do {
                System.out.println("----------------------------------------------");
                System.out.println("1. Enroll");
                System.out.println("2. Update");
                System.out.println("3. View");
                System.out.println("4. Exit");
                System.out.print("Enter your option: ");
                opt = inp.nextLine();
                System.out.println("----------------------------------------------");
            } while ((!opt.equals("1"))
                    && (!opt.equals("2"))
                    && (!opt.equals("3"))
                    && (!opt.equals("4")));

            // Check option is valid or not
            if ((Integer.parseInt(opt) >= 1)
                    && (Integer.parseInt(opt) <= 4)) {
                switch (opt) {
                    case "1": // Enroll

                        // Enter Student ID
                        do {
                            System.out.println("----------------------------------------------");
                            System.out.print("Enter a Student ID: ");
                            sID = inp.nextLine().toUpperCase(); // Uppercase all of the inputs
                            s = enrolment.isStudentValid(sID);
                            System.out.println("----------------------------------------------");
                        } while (s == null);

                        // Enter Course ID
                        do {
                            System.out.println("----------------------------------------------");
                            System.out.print("Enter a Course ID: ");
                            cID = inp.nextLine().toUpperCase();
                            c = enrolment.isCourseValid(cID);
                            System.out.println("----------------------------------------------");
                        } while (c == null);

                        // Enter Semester
                        do {
                            System.out.println("----------------------------------------------");
                            System.out.print("Enter a Semester: ");
                            sem = inp.nextLine().toUpperCase();
                            System.out.println("----------------------------------------------");
                        } while (!Pattern.matches(String.valueOf(regex), sem));

                        // Check the enrolment is available or not
                        StudentEnrolment se = new StudentEnrolment(s, c, sem);
                        if (enrolment.add(se)) {
                            System.out.println("Enroll Successfully");
                        }
                        else {
                            System.out.println("Already was there");
                        }
                        break;

                    case "2": // Update

                        // Enter Student ID
                        do {
                            System.out.println("----------------------------------------------");
                            System.out.print("Enter a Student ID: ");
                            sID = inp.nextLine().toUpperCase();
                            s = enrolment.isStudentValid(sID);
                            System.out.println("----------------------------------------------");
                        } while (s == null);

                        // Display student's course list
                        System.out.println(s.getName() + "'s Course List: ");
                        int noCourse = enrolment.displayCourseOfStudent(sID);

                        // Ask users to choose add or delete a new enrolment
                        do {
                            System.out.println("----------------------------------------------");
                            System.out.println("1. Add a new course");
                            System.out.println("2. Delete a enrolment");
                            System.out.println("3. Back");
                            System.out.print("Enter your option: ");
                            opt1 = inp.nextLine();
                            System.out.println("----------------------------------------------");
                        } while (!opt1.equals("1")
                                && (!opt1.equals("2"))
                                && (!opt1.equals("3")));

                        switch (opt1) {
                            case "1": // Add

                                // Enter Course ID
                                do {
                                    System.out.println("----------------------------------------------");
                                    System.out.print("Enter a Course ID: ");
                                    cID = inp.nextLine().toUpperCase();
                                    c = enrolment.isCourseValid(cID);
                                    System.out.println("----------------------------------------------");
                                } while (c == null);

                                // Enter Semester
                                do {
                                    System.out.println("----------------------------------------------");
                                    System.out.print("Enter a Semester: ");
                                    sem = inp.nextLine().toUpperCase();
                                    System.out.println("----------------------------------------------");
                                } while (!Pattern.matches(String.valueOf(regex), sem));

                                // Add a new course for a student
                                if (enrolment.update(s, c, sem)) {
                                    System.out.println("Update Successfully");
                                }
                                else System.out.println("Already there!");
                                break;

                            case "2": // Delete

                                // Delete Enrolment
                                enrolment.delete(enrolment.getOne(noCourse, sID));
                                break;
                        }
                        break;

                    case "3": // View

                        do {
                            System.out.println("----------------------------------------------");
                            System.out.println("1. View all courses of a student in a semester");
                            System.out.println("2. View all students in a course in a semester");
                            System.out.println("3. View all course offered in a semester");
                            System.out.println("4. View all enrolments/ students/ courses");
                            System.out.println("5. Back");
                            System.out.print("Enter your option: ");
                            opt2 = inp.nextLine();
                            System.out.println("----------------------------------------------");
                        } while (!opt2.equals("1")
                                && !opt2.equals("2")
                                && !opt2.equals("3")
                                && !opt2.equals("4")
                                && !opt2.equals("5"));

                        enrolment.view(opt2);
                        break;

                    case "4": // Exit
                        break;
                }
            }

            // If option is not 1 - 4
            else {
                System.out.println("----------------------------------------------");
                System.out.println("Invalid Option!");
                System.out.println("----------------------------------------------");
            }
        } while (!opt.equals("4"));
    }
}
