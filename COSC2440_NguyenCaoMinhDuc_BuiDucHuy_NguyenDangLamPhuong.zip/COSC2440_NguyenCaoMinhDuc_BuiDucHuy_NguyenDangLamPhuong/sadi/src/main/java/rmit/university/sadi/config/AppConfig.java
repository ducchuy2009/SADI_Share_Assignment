//package rmit.university.sadi.config;
//
//
//
//import org.hibernate.SessionFactory;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.orm.hibernate5.HibernateTransactionManager;
//import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//import java.util.Properties;
//
///**
// * Created by CoT on 10/14/17.
// */
//@Configuration
//@EnableTransactionManagement
//public class AppConfig {
////
//
//    @Bean
//    public LocalSessionFactoryBean sessionFactory(){
//
//        Properties properties = new Properties();
//        properties.put("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
//        properties.put("hibernate.show_sql", true);
//        properties.put("hibernate.hbm2ddl.auto", "create-drop");
//
//        DriverManagerDataSource dataSource = new DriverManagerDataSource();
//
//        //To use postgresql
//        dataSource.setDriverClassName("org.postgresql.Driver");
//        dataSource.setUrl("jdbc:postgresql://localhost:5432/assignment2");
//        dataSource.setUsername("postgres");
//        dataSource.setPassword("minhduc123");
//
//
//        LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
//        sessionFactoryBean.setDataSource(dataSource);
//
//        sessionFactoryBean.setHibernateProperties(properties);
//        sessionFactoryBean.setPackagesToScan("rmit.university.sadi.entity");
//
//
//        return  sessionFactoryBean;
//    }
//
//
//    @Bean
//    public HibernateTransactionManager transactionManager(SessionFactory sessionFactory){
//        HibernateTransactionManager tx = new HibernateTransactionManager(sessionFactory);
//
//        return tx;
//    }
//
//}
//
//
//
