package rmit.university.sadi.repository;

public enum Status {
    IN_PROGRESS, //
    COMPLETED, //
    CANCELLED
}
