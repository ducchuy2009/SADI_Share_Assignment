package rmit.university.sadi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SadiApplication {

	public static void main(String[] args) {

		SpringApplication.run(SadiApplication.class, args);
	}

}
